vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|27 Apr 2012 07:28:44 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|PANITZBITLAPTOP\\MikePanitz
vti_modifiedby:SR|PANITZBITLAPTOP\\MikePanitz
vti_nexttolasttimemodified:TR|23 Sep 2008 12:40:54 -0000
vti_timecreated:TR|27 Apr 2012 07:28:44 -0000
vti_cacheddtm:TX|23 Sep 2008 12:40:54 -0000
vti_filesize:IR|1312
vti_backlinkinfo:VX|
